import * as vscode from 'vscode';
import { List, Download, Upload, Create, Delete, IZosFilesResponse } from '@zowe/zos-files-for-zowe-sdk';
import { ZoweSessionManager } from '../zowe/session';
import { TelemetryService } from '../utils/telemetry';
import { DsIntentClassifier } from '../intents/ds.classifier';
import {
    DsIntent,
    INTENT_SAFETY,
    SafetyLevel,
} from '../intents/ds.schemas';
import {
    requestConfirmation,
    getEffectiveSafetyLevel,
    describeOperation,
} from '../zowe/safety';

// ============================================================
// Handler /ds — Datasets & Membres PDS
// 
// Architecture :
//   1. Classifier LLM → Intent structuré
//   2. Vérification sécurité (confirmation si nécessaire)
//   3. Appel Zowe SDK
//   4. Formatage réponse dans le stream
// ============================================================

export class DatasetsHandler {
    private classifier: DsIntentClassifier;

    constructor(
        private sessionManager: ZoweSessionManager,
        private telemetry: TelemetryService
    ) {
        this.classifier = new DsIntentClassifier();
    }

    async handle(
        request: vscode.ChatRequest,
        chatContext: vscode.ChatContext,
        stream: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ): Promise<void> {
        const prompt = request.prompt.trim();

        if (!prompt) {
            stream.markdown(
                `**Commande /ds** — Gestion des datasets z/OS\n\n` +
                `Exemples :\n` +
                `- \`liste les datasets HLQ.**\`\n` +
                `- \`montre les membres de HLQ.COBOL.SRC\`\n` +
                `- \`affiche HLQ.COBOL.SRC(PGMA)\`\n` +
                `- \`cherche PERFORM dans HLQ.COBOL.SRC\`\n` +
                `- \`info sur HLQ.COBOL.LOAD\`\n` +
                `- \`supprime le membre OLDPGM de HLQ.COBOL.SRC\`\n`
            );
            return;
        }

        // ── Step 1 : Classification de l'intent ──
        stream.progress('Analyse de la requête...');
        const intent = await this.classifier.classify(prompt, token);

        if (!intent) {
            stream.markdown(
                `🤔 Je n'ai pas compris votre requête sur les datasets.\n\n` +
                `Essayez par exemple : \`@zos /ds liste les datasets HLQ.**\``
            );
            return;
        }

        // ── Step 2 : Vérification sécurité ──
        const datasetName = this.extractDatasetName(intent);
        const baseSafety = INTENT_SAFETY[intent.type];
        const effectiveSafety = getEffectiveSafetyLevel(baseSafety, datasetName);

        if (effectiveSafety !== 'safe') {
            const description = describeOperation(intent.type, intent as any);
            const confirmed = await requestConfirmation(
                stream, description, effectiveSafety, datasetName
            );
            if (!confirmed) {
                return;
            }
        }

        // ── Step 3 : Exécution via Zowe SDK ──
        stream.progress('Connexion à z/OS...');
        const { session, profileName } = await this.sessionManager.getSession();

        stream.progress(`Exécution ${intent.type}...`);

        switch (intent.type) {
            case 'LIST_DATASETS':
                await this.listDatasets(session, intent.pattern, stream);
                break;
            case 'LIST_MEMBERS':
                await this.listMembers(session, intent.dataset, stream, intent.pattern);
                break;
            case 'READ_MEMBER':
                await this.readMember(session, intent.dataset, intent.member, stream);
                break;
            case 'WRITE_MEMBER':
                await this.writeMember(session, intent.dataset, intent.member, intent.content, stream);
                break;
            case 'CREATE_DATASET':
                await this.createDataset(session, intent, stream);
                break;
            case 'CREATE_MEMBER':
                await this.createMember(session, intent.dataset, intent.member, intent.content, stream);
                break;
            case 'DELETE_MEMBER':
                await this.deleteMember(session, intent.dataset, intent.member, stream);
                break;
            case 'DELETE_DATASET':
                await this.deleteDataset(session, intent.dataset, stream);
                break;
            case 'SEARCH_CONTENT':
                await this.searchContent(session, intent.dataset, intent.searchTerm, stream, intent.memberPattern);
                break;
            case 'DATASET_INFO':
                await this.datasetInfo(session, intent.dataset, stream);
                break;
        }

        this.telemetry.trackSuccess('ds', intent.type, profileName);
    }

    // ================================================================
    // LIST_DATASETS — Lister les datasets correspondant à un pattern
    // ================================================================
    private async listDatasets(
        session: any,
        pattern: string,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        const response: IZosFilesResponse = await List.dataSet(session, pattern, {
            attributes: true,
        });

        const items = response.apiResponse?.items ?? [];

        if (items.length === 0) {
            stream.markdown(`Aucun dataset trouvé pour le pattern \`${pattern}\`.`);
            return;
        }

        stream.markdown(`### 📁 Datasets — \`${pattern}\` (${items.length} résultats)\n\n`);
        stream.markdown(`| Dataset | Organisation | RECFM | LRECL | Volume |\n`);
        stream.markdown(`|---------|-------------|-------|-------|--------|\n`);

        for (const ds of items) {
            const dsorg = ds.dsorg ?? '-';
            const recfm = ds.recfm ?? '-';
            const lrecl = ds.lrecl ?? '-';
            const vol = ds.vol ?? '-';
            stream.markdown(`| \`${ds.dsname}\` | ${dsorg} | ${recfm} | ${lrecl} | ${vol} |\n`);
        }

        // Proposer des actions suivantes
        stream.markdown(
            `\n💡 *Vous pouvez ensuite :*\n` +
            `- \`/ds montre les membres de <DATASET>\`\n` +
            `- \`/ds info sur <DATASET>\`\n`
        );
    }

    // ================================================================
    // LIST_MEMBERS — Lister les membres d'un PDS
    // ================================================================
    private async listMembers(
        session: any,
        dataset: string,
        stream: vscode.ChatResponseStream,
        pattern?: string
    ): Promise<void> {
        const response: IZosFilesResponse = await List.allMembers(session, dataset, {
            attributes: true,
            pattern: pattern,
        });

        const items = response.apiResponse?.items ?? [];

        if (items.length === 0) {
            stream.markdown(
                pattern
                    ? `Aucun membre correspondant à \`${pattern}\` dans \`${dataset}\`.`
                    : `Le dataset \`${dataset}\` ne contient aucun membre (ou n'est pas un PDS).`
            );
            return;
        }

        stream.markdown(`### 📄 Membres de \`${dataset}\` (${items.length})\n\n`);

        // Format compact si beaucoup de membres, détaillé sinon
        if (items.length > 20) {
            // Format colonnes compactes
            const columns = 4;
            const rows = Math.ceil(items.length / columns);
            stream.markdown(`| ${Array(columns).fill('Membre').join(' | ')} |\n`);
            stream.markdown(`| ${Array(columns).fill('------').join(' | ')} |\n`);

            for (let r = 0; r < rows; r++) {
                const cells = [];
                for (let c = 0; c < columns; c++) {
                    const idx = r + c * rows;
                    cells.push(idx < items.length ? `\`${items[idx].member}\`` : '');
                }
                stream.markdown(`| ${cells.join(' | ')} |\n`);
            }
        } else {
            // Format détaillé avec stats
            stream.markdown(`| Membre | Modifié | Taille | ID |\n`);
            stream.markdown(`|--------|---------|--------|----|\n`);

            for (const m of items) {
                const modified = m.changed ?? m.m4date ?? '-';
                const size = m.init !== undefined ? `${m.init} lignes` : '-';
                const user = m.user ?? '-';
                stream.markdown(`| \`${m.member}\` | ${modified} | ${size} | ${user} |\n`);
            }
        }

        stream.markdown(
            `\n💡 \`/ds affiche ${dataset}(<MEMBRE>)\` pour lire un membre.`
        );
    }

    // ================================================================
    // READ_MEMBER — Lire le contenu d'un membre
    // ================================================================
    private async readMember(
        session: any,
        dataset: string,
        member: string,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        const content = await Download.dataSet(session, `${dataset}(${member})`, {
            returnEtag: false,
            stream: undefined as any, // Force le retour en buffer
        });

        // Download.dataSet retourne le contenu via apiResponse
        const text = typeof content.apiResponse === 'string'
            ? content.apiResponse
            : Buffer.from(content.apiResponse).toString('utf-8');

        if (!text || text.trim().length === 0) {
            stream.markdown(`Le membre \`${dataset}(${member})\` est vide.`);
            return;
        }

        const lines = text.split('\n');
        const lang = this.detectLanguage(member, text);

        stream.markdown(`### 📝 \`${dataset}(${member})\` — ${lines.length} lignes\n\n`);
        stream.markdown(`\`\`\`${lang}\n${text}\n\`\`\`\n`);

        // Proposer d'ouvrir dans l'éditeur
        stream.button({
            command: 'zos.openMember',
            title: '📂 Ouvrir dans l\'éditeur',
            arguments: [dataset, member],
        });
    }

    // ================================================================
    // WRITE_MEMBER — Écrire le contenu d'un membre
    // ================================================================
    private async writeMember(
        session: any,
        dataset: string,
        member: string,
        content: string,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        const buffer = Buffer.from(content, 'utf-8');

        await Upload.bufferToDataSet(session, buffer, `${dataset}(${member})`, {
            binary: false,
        });

        const lines = content.split('\n').length;
        stream.markdown(
            `✅ **Écriture réussie** — \`${dataset}(${member})\`\n\n` +
            `${lines} lignes écrites.`
        );
    }

    // ================================================================
    // CREATE_DATASET — Créer un nouveau dataset
    // ================================================================
    private async createDataset(
        session: any,
        intent: {
            name: string;
            dsorg: 'PO' | 'PS';
            recfm?: string;
            lrecl?: number;
            blksize?: number;
            primary?: number;
            secondary?: number;
        },
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        const options: any = {
            dsorg: intent.dsorg,
            alcunit: 'TRK',
            primary: intent.primary ?? 10,
            secondary: intent.secondary ?? 5,
            recfm: intent.recfm ?? 'FB',
            lrecl: intent.lrecl ?? 80,
            blksize: intent.blksize ?? 27920,
        };

        // Pour un PDS, ajouter le directory blocks
        if (intent.dsorg === 'PO') {
            options.dirblk = 20;
            options.dsntype = 'PDS';
        }

        await Create.dataSet(session, intent.dsorg === 'PO' ? 1 : 4, intent.name, options);

        stream.markdown(
            `✅ **Dataset créé** — \`${intent.name}\`\n\n` +
            `| Propriété | Valeur |\n` +
            `|-----------|--------|\n` +
            `| Organisation | ${intent.dsorg} |\n` +
            `| RECFM | ${options.recfm} |\n` +
            `| LRECL | ${options.lrecl} |\n` +
            `| BLKSIZE | ${options.blksize} |\n` +
            `| Primaire | ${options.primary} TRK |\n` +
            `| Secondaire | ${options.secondary} TRK |\n`
        );
    }

    // ================================================================
    // CREATE_MEMBER — Créer un membre dans un PDS
    // ================================================================
    private async createMember(
        session: any,
        dataset: string,
        member: string,
        content: string | undefined,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        const data = content ?? '';
        const buffer = Buffer.from(data, 'utf-8');

        await Upload.bufferToDataSet(session, buffer, `${dataset}(${member})`, {
            binary: false,
        });

        stream.markdown(
            `✅ **Membre créé** — \`${dataset}(${member})\`\n\n` +
            (content ? `${content.split('\n').length} lignes écrites.` : `Membre vide créé.`)
        );
    }

    // ================================================================
    // DELETE_MEMBER — Supprimer un membre
    // ================================================================
    private async deleteMember(
        session: any,
        dataset: string,
        member: string,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        await Delete.dataSet(session, `${dataset}(${member})`);

        stream.markdown(
            `✅ **Membre supprimé** — \`${dataset}(${member})\``
        );
    }

    // ================================================================
    // DELETE_DATASET — Supprimer un dataset entier
    // ================================================================
    private async deleteDataset(
        session: any,
        dataset: string,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        await Delete.dataSet(session, dataset);

        stream.markdown(
            `✅ **Dataset supprimé** — \`${dataset}\``
        );
    }

    // ================================================================
    // SEARCH_CONTENT — Rechercher du texte dans les membres d'un PDS
    // ================================================================
    private async searchContent(
        session: any,
        dataset: string,
        searchTerm: string,
        stream: vscode.ChatResponseStream,
        memberPattern?: string
    ): Promise<void> {
        // 1. Lister les membres
        const membersResponse = await List.allMembers(session, dataset, {
            pattern: memberPattern,
        });
        const members = membersResponse.apiResponse?.items ?? [];

        if (members.length === 0) {
            stream.markdown(`Aucun membre trouvé dans \`${dataset}\`.`);
            return;
        }

        stream.markdown(`### 🔍 Recherche de \`${searchTerm}\` dans \`${dataset}\`\n\n`);
        stream.progress(`Recherche dans ${members.length} membres...`);

        const results: { member: string; lines: { num: number; text: string }[] }[] = [];
        let scannedCount = 0;

        // 2. Lire chaque membre et chercher
        // Limiter à 50 membres pour ne pas surcharger
        const maxMembers = Math.min(members.length, 50);

        for (let i = 0; i < maxMembers; i++) {
            const memberName = members[i].member;
            try {
                const content = await Download.dataSet(
                    session,
                    `${dataset}(${memberName})`,
                    { returnEtag: false, stream: undefined as any }
                );

                const text = typeof content.apiResponse === 'string'
                    ? content.apiResponse
                    : Buffer.from(content.apiResponse).toString('utf-8');

                const matchingLines: { num: number; text: string }[] = [];
                const lines = text.split('\n');

                for (let lineNum = 0; lineNum < lines.length; lineNum++) {
                    if (lines[lineNum].toUpperCase().includes(searchTerm.toUpperCase())) {
                        matchingLines.push({
                            num: lineNum + 1,
                            text: lines[lineNum].trimEnd(),
                        });
                    }
                }

                if (matchingLines.length > 0) {
                    results.push({ member: memberName, lines: matchingLines });
                }
            } catch {
                // Ignorer les erreurs de lecture individuelles
            }
            scannedCount++;
        }

        // 3. Afficher les résultats
        if (results.length === 0) {
            stream.markdown(`Aucune occurrence de \`${searchTerm}\` trouvée dans ${scannedCount} membres.`);
            return;
        }

        const totalHits = results.reduce((sum, r) => sum + r.lines.length, 0);
        stream.markdown(
            `**${totalHits} occurrences** dans **${results.length} membres** ` +
            `(${scannedCount}/${members.length} membres scannés)\n\n`
        );

        for (const result of results) {
            stream.markdown(`#### \`${result.member}\` — ${result.lines.length} occurrence(s)\n`);
            stream.markdown(`\`\`\`\n`);
            for (const line of result.lines.slice(0, 10)) {
                stream.markdown(`${String(line.num).padStart(6)} | ${line.text}\n`);
            }
            if (result.lines.length > 10) {
                stream.markdown(`  ... et ${result.lines.length - 10} autres lignes\n`);
            }
            stream.markdown(`\`\`\`\n\n`);
        }

        if (members.length > maxMembers) {
            stream.markdown(
                `\n⚠️ Recherche limitée à ${maxMembers}/${members.length} membres. ` +
                `Utilisez un pattern pour affiner : \`/ds cherche ${searchTerm} dans ${dataset} membres COB*\``
            );
        }
    }

    // ================================================================
    // DATASET_INFO — Obtenir les caractéristiques d'un dataset
    // ================================================================
    private async datasetInfo(
        session: any,
        dataset: string,
        stream: vscode.ChatResponseStream
    ): Promise<void> {
        const response = await List.dataSet(session, dataset, {
            attributes: true,
        });

        const items = response.apiResponse?.items ?? [];

        if (items.length === 0) {
            stream.markdown(`Dataset \`${dataset}\` non trouvé.`);
            return;
        }

        const ds = items[0];

        stream.markdown(`### ℹ️ Informations — \`${ds.dsname}\`\n\n`);
        stream.markdown(`| Propriété | Valeur |\n`);
        stream.markdown(`|-----------|--------|\n`);

        const props: [string, any][] = [
            ['Organisation', ds.dsorg],
            ['RECFM', ds.recfm],
            ['LRECL', ds.lrecl],
            ['BLKSIZE', ds.blksize],
            ['Volume', ds.vol],
            ['Unité', ds.unit],
            ['Création', ds.cdate],
            ['Référencé', ds.rdate],
            ['Expiration', ds.edate],
            ['Taille utilisée', ds.used !== undefined ? `${ds.used} extents` : undefined],
            ['Taille primaire', ds.primary],
            ['Taille secondaire', ds.secondary],
            ['Catalogue', ds.catnm],
            ['SMS Class (Data)', ds.dataclass],
            ['SMS Class (Mgmt)', ds.mgntclass],
            ['SMS Class (Storage)', ds.storeclass],
        ];

        for (const [label, value] of props) {
            if (value !== undefined && value !== null && value !== '') {
                stream.markdown(`| ${label} | \`${value}\` |\n`);
            }
        }

        // Si c'est un PDS, proposer de lister les membres
        if (ds.dsorg?.includes('PO')) {
            stream.markdown(`\n💡 C'est un PDS. \`/ds montre les membres de ${dataset}\``);
        }
    }

    // ================================================================
    // Utilitaires
    // ================================================================

    /**
     * Extrait le nom du dataset principal depuis un intent
     */
    private extractDatasetName(intent: DsIntent): string {
        switch (intent.type) {
            case 'LIST_DATASETS':
                return intent.pattern;
            case 'CREATE_DATASET':
                return intent.name;
            default:
                return (intent as any).dataset ?? '';
        }
    }

    /**
     * Détecte le langage pour la coloration syntaxique
     */
    private detectLanguage(member: string, content: string): string {
        // Heuristiques basées sur le contenu
        if (content.match(/^\s{6}\w/m) || content.includes('IDENTIFICATION DIVISION')) {
            return 'cobol';
        }
        if (content.includes('//') && content.includes(' DD ')) {
            return 'jcl';
        }
        if (member.startsWith('ASM') || content.includes(' CSECT') || content.includes(' USING ')) {
            return 'asm';
        }
        if (content.includes('PROC ') && content.includes('END;')) {
            return 'pli';
        }
        if (content.includes('<') && content.includes('>')) {
            return 'xml';
        }
        // Par défaut COBOL (le plus courant dans le contexte mainframe)
        return 'text';
    }
}
