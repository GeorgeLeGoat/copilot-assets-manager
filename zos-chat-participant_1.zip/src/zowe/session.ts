import * as vscode from 'vscode';
import { imperative } from '@zowe/zowe-explorer-api';

// ============================================================
// Gestion des sessions Zowe
// Se branche sur les profils Zowe Explorer existants
// pour ne pas redemander les credentials
// ============================================================

export interface ZoweSession {
    session: imperative.Session;
    profileName: string;
}

export class ZoweSessionManager {
    private cachedSession: ZoweSession | null = null;

    /**
     * Récupère la session Zowe active.
     * Stratégie :
     * 1. Cache en mémoire (pour la durée de la session VS Code)
     * 2. Profil Zowe Explorer actif
     * 3. zowe.config.json / zowe.config.user.json
     */
    async getSession(): Promise<ZoweSession> {
        if (this.cachedSession) {
            return this.cachedSession;
        }

        // Stratégie 1 : Utiliser l'API Zowe Explorer si disponible
        const zoweExplorerApi = this.getZoweExplorerApi();
        if (zoweExplorerApi) {
            try {
                const session = await this.getSessionFromZoweExplorer(zoweExplorerApi);
                if (session) {
                    this.cachedSession = session;
                    return session;
                }
            } catch (error) {
                console.warn('[zos] Could not get session from Zowe Explorer:', error);
            }
        }

        // Stratégie 2 : Charger depuis le Team Config (zowe.config.json)
        try {
            const session = await this.getSessionFromTeamConfig();
            if (session) {
                this.cachedSession = session;
                return session;
            }
        } catch (error) {
            console.warn('[zos] Could not load Team Config:', error);
        }

        throw new Error(
            'Impossible de se connecter à z/OS. ' +
            'Vérifiez que Zowe Explorer est installé avec un profil configuré, ' +
            'ou qu\'un fichier zowe.config.json est présent dans le workspace.'
        );
    }

    /**
     * Invalide le cache (utile si le profil change)
     */
    clearCache(): void {
        this.cachedSession = null;
    }

    /**
     * Tente de récupérer l'extension Zowe Explorer
     */
    private getZoweExplorerApi(): any | undefined {
        try {
            const zoweExplorer = vscode.extensions.getExtension('Zowe.vscode-extension-for-zowe');
            if (zoweExplorer?.isActive) {
                return zoweExplorer.exports;
            }
        } catch {
            // Zowe Explorer non installé
        }
        return undefined;
    }

    /**
     * Récupère la session depuis le profil Zowe Explorer actif
     */
    private async getSessionFromZoweExplorer(api: any): Promise<ZoweSession | null> {
        // L'API Zowe Explorer expose les profils enregistrés
        const profileCache = api?.getExplorerExtenderApi?.()?.getProfilesCache?.();
        if (!profileCache) {
            return null;
        }

        const defaultProfile = profileCache.getDefaultProfile('zosmf');
        if (!defaultProfile) {
            return null;
        }

        const baseProfile = profileCache.getDefaultProfile('base');

        // Construire la session à partir du profil
        const mergedProfile = {
            ...baseProfile?.profile,
            ...defaultProfile.profile,
        };

        const session = new imperative.Session({
            hostname: mergedProfile.host,
            port: mergedProfile.port,
            user: mergedProfile.user,
            password: mergedProfile.password,
            type: imperative.SessConstants.AUTH_TYPE_BASIC,
            basePath: mergedProfile.basePath,
            rejectUnauthorized: mergedProfile.rejectUnauthorized ?? true,
            protocol: mergedProfile.protocol ?? 'https',
        });

        return {
            session,
            profileName: defaultProfile.name ?? 'default',
        };
    }

    /**
     * Charge la session depuis le Zowe Team Config (zowe.config.json)
     */
    private async getSessionFromTeamConfig(): Promise<ZoweSession | null> {
        // Chercher zowe.config.json dans le workspace
        const configFiles = await vscode.workspace.findFiles(
            '**/zowe.config.json',
            '**/node_modules/**',
            1
        );

        if (configFiles.length === 0) {
            return null;
        }

        const configContent = await vscode.workspace.fs.readFile(configFiles[0]);
        const config = JSON.parse(Buffer.from(configContent).toString());

        // Extraire le profil par défaut
        const defaultProfileName = config.defaults?.zosmf;
        if (!defaultProfileName) {
            return null;
        }

        const profile = config.profiles?.[defaultProfileName]?.properties;
        const baseProfile = config.profiles?.base?.properties;

        if (!profile) {
            return null;
        }

        const merged = { ...baseProfile, ...profile };

        const session = new imperative.Session({
            hostname: merged.host,
            port: merged.port,
            user: merged.user,
            password: merged.password,
            type: imperative.SessConstants.AUTH_TYPE_BASIC,
            basePath: merged.basePath,
            rejectUnauthorized: merged.rejectUnauthorized ?? true,
            protocol: merged.protocol ?? 'https',
        });

        return {
            session,
            profileName: defaultProfileName,
        };
    }
}
