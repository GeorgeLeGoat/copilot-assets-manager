import * as vscode from 'vscode';
import { ZoweSessionManager } from '../zowe/session';
import { TelemetryService } from '../utils/telemetry';

// ============================================================
// Stubs pour les handlers restants
// À implémenter sur le même modèle que DatasetsHandler / JobsHandler
// ============================================================

export class TsoHandler {
    constructor(
        private sessionManager: ZoweSessionManager,
        private telemetry: TelemetryService
    ) {}

    async handle(
        request: vscode.ChatRequest,
        chatContext: vscode.ChatContext,
        stream: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ): Promise<void> {
        stream.markdown(
            `**Commande /tso** — *Implémentation à venir*\n\n` +
            `Prévu :\n` +
            `- Exécution de commandes TSO\n` +
            `- Commandes console z/OS (D A,L / D GRS, etc.)\n`
        );
    }
}

export class UssHandler {
    constructor(
        private sessionManager: ZoweSessionManager,
        private telemetry: TelemetryService
    ) {}

    async handle(
        request: vscode.ChatRequest,
        chatContext: vscode.ChatContext,
        stream: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ): Promise<void> {
        stream.markdown(
            `**Commande /uss** — *Implémentation à venir*\n\n` +
            `Prévu :\n` +
            `- Navigation dans le filesystem USS\n` +
            `- Lecture/écriture de fichiers USS\n` +
            `- Exécution de commandes shell\n`
        );
    }
}
