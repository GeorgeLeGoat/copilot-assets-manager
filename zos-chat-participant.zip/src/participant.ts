import * as vscode from 'vscode';
import { DatasetsHandler } from './handlers/datasets.handler';
import { JobsHandler, RunHandler, TsoHandler, UssHandler } from './handlers';
import { ZoweSessionManager } from './zowe/session';
import { TelemetryService } from './utils/telemetry';

const PARTICIPANT_ID = 'zdevops.zos';

export function activate(context: vscode.ExtensionContext) {
    const sessionManager = new ZoweSessionManager();
    const telemetry = new TelemetryService(context);

    const datasetsHandler = new DatasetsHandler(sessionManager, telemetry);
    const jobsHandler = new JobsHandler(sessionManager, telemetry);
    const runHandler = new RunHandler(sessionManager, telemetry);
    const tsoHandler = new TsoHandler(sessionManager, telemetry);
    const ussHandler = new UssHandler(sessionManager, telemetry);

    const handler: vscode.ChatRequestHandler = async (
        request: vscode.ChatRequest,
        chatContext: vscode.ChatContext,
        stream: vscode.ChatResponseStream,
        token: vscode.CancellationToken
    ) => {
        const startTime = Date.now();

        try {
            switch (request.command) {
                case 'ds':
                    return await datasetsHandler.handle(request, chatContext, stream, token);
                case 'jobs':
                    return await jobsHandler.handle(request, chatContext, stream, token);
                case 'run':
                    return await runHandler.handle(request, chatContext, stream, token);
                case 'tso':
                    return await tsoHandler.handle(request, chatContext, stream, token);
                case 'uss':
                    return await ussHandler.handle(request, chatContext, stream, token);
                default:
                    return await handleFreeForm(request, chatContext, stream, token);
            }
        } catch (error: any) {
            telemetry.trackError(request.command ?? 'freeform', error);
            stream.markdown(`\n\n⚠️ **Erreur z/OS** : ${formatZoweError(error)}`);
        } finally {
            telemetry.trackDuration(request.command ?? 'freeform', Date.now() - startTime);
        }
    };

    const participant = vscode.chat.createChatParticipant(PARTICIPANT_ID, handler);
    participant.iconPath = new vscode.ThemeIcon('server');

    context.subscriptions.push(participant);
}

async function handleFreeForm(
    request: vscode.ChatRequest,
    chatContext: vscode.ChatContext,
    stream: vscode.ChatResponseStream,
    token: vscode.CancellationToken
) {
    stream.markdown(
        `Je peux vous aider à interagir avec z/OS. Utilisez une commande pour cibler votre besoin :\n\n` +
        `- \`/ds\` — Datasets & membres PDS\n` +
        `- \`/jobs\` — Statut et spool des jobs\n` +
        `- \`/run\` — Soumettre du JCL\n` +
        `- \`/tso\` — Commandes TSO/Console\n` +
        `- \`/uss\` — Filesystem USS\n\n` +
        `Ou posez directement votre question, j'essaierai de comprendre votre besoin.`
    );
}

function formatZoweError(error: any): string {
    if (error?.mDetails?.additionalDetails) {
        return `${error.message}\n\`\`\`\n${error.mDetails.additionalDetails}\n\`\`\``;
    }
    if (error?.causeErrors) {
        try {
            const cause = JSON.parse(error.causeErrors);
            return `RC=${cause.rc ?? '?'} — ${cause.message ?? error.message}`;
        } catch {
            return error.message;
        }
    }
    return error?.message ?? 'Erreur inconnue';
}

export function deactivate() {}
